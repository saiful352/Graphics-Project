#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#include <windows.h>
#include <glut.h>
#define pi (2*acos(0.0))

double cameraHeight;
double cameraAngle;
int drawgrid;
int drawaxes;
double angle=20;
double incx=50, incy;
int state;
struct point
{
	double x,y,z;
};

void push_pop(void)
{
    glPushMatrix();
        glRotatef(45, 0, 0, 1);
        glPushMatrix(); // Furthest Triangle, Draw first


            //glRotatef(45, 0, 0, 1);
            glTranslatef(-20, 0, 0);
            //glScaled(2, 1, 0);
            glColor3f(0.0, 0.0, 1.0);
            glBegin(GL_POLYGON);
                glVertex2f(10, 10);
                glVertex2f(10, 0);
                glVertex2f(-10, 0);
            glEnd();
        glPopMatrix();

        glPushMatrix(); // Middle Triangle, Draw 2nd
            glColor3f(0.0, 1.0, 0.0);
            glBegin(GL_POLYGON);
                glVertex2f(10, 10);
                glVertex2f(10, 0);
                glVertex2f(-10, 0);
            glEnd();
        glPopMatrix();

        glPushMatrix(); // Nearest Triangle, Draw last
            glTranslatef(20, 0, 0);
            glColor3f(1.0, 0.0, 0.0);
            glBegin(GL_POLYGON);
                glVertex2f(10, 10);
                glVertex2f(10, 0);
                glVertex2f(-10, 0);
            glEnd();
        glPopMatrix();



    glPopMatrix();

}


void drawAxes()
{

		glColor3f(1.0, 1.0, 1.0);
		glBegin(GL_LINES);{
			glVertex3f( 100,0,0);
			glVertex3f(-100,0,0);

			glVertex3f(0,-100,0);
			glVertex3f(0, 100,0);

			glVertex3f(0,0, 100);
			glVertex3f(0,0,-100);
		}glEnd();

}


void drawGrid()
{
	int i;

    glColor3f(0.6, 0.6, 0.6);	//grey
    glBegin(GL_LINES);{
        for(i=-8;i<=8;i++){

            if(i==0)
                continue;	//SKIP the MAIN axes

            //lines parallel to Y-axis
            glVertex3f(i*10, -90, 0);
            glVertex3f(i*10,  90, 0);

            //lines parallel to X-axis
            glVertex3f(-90, i*10, 0);
            glVertex3f( 90, i*10, 0);
        }
    }glEnd();

}





void just_line()
{
      glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_LINES);

        glVertex2d(89.0,120.0);
        glVertex2d(94.0,120.0);

    glEnd();

     glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_LINES);

        glVertex2d(86.0,118.0);
        glVertex2d(89.0,120.0);

    glEnd();


     glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_LINES);

        glVertex2d(83.0,120.0);
        glVertex2d(86.0,118.0);

    glEnd();


    glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_LINES);

        glVertex2d(78.0,120.0);
        glVertex2d(83.0,120.0);

    glEnd();


    //1ST BIRD
      glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_LINES);

        glVertex2d(71.0,120.0);
        glVertex2d(76.0,120.0);

    glEnd();


     glColor3f(0.0f, 0.0f, 0.0f); //BLUE LINE
    glBegin(GL_LINES); // It can be any type Gl_POINT,_LINE

        glVertex2d(68.0,118.0);
        glVertex2d(71.0,120.0);

    glEnd();


    glColor3f(0.0f, 0.0f, 0.0f); //BLUE LINE
    glBegin(GL_LINES); // It can be any type Gl_POINT,_LINE

        glVertex2d(65.0,120.0);
        glVertex2d(68.0,118.0);

    glEnd();



    glColor3f(0.0f, 0.0f, 0.0f); //BLUE LINE
    glBegin(GL_LINES); // It can be any type Gl_POINT,_LINE

        glVertex2d(60.0,120.0);
        glVertex2d(65.0,120.0);

    glEnd();

}
void lines()
{
    glColor3f(0.0f, 1.0f, 0.0f); // GREEN RECTANGLE
    glBegin(GL_LINE_LOOP); // It can be any type Gl_POINT,_LINE

        glVertex2d(20,20);
        glVertex2d(-20,20);
        glVertex2d(0,0);
        glVertex2d(-20,-20);
        glVertex2d(20,-20);
        glVertex2d(0,0);



    glEnd();
}
void triangle()
{
    glColor3f(1.0f, 0.0f, 0.0f); //RED TRIANGLE
    glBegin(GL_LINE_LOOP); // It can be any type Gl_POINT,_LINE

        glVertex2d(0.0,2.5);
        glVertex2d(-2.5,0.0);
        glVertex2d(2.5,0.0);

    glEnd();

}

void s_triangle()
{
    glPushMatrix();
    glTranslatef(-135,-120,0);
    glBegin(GL_TRIANGLES); // DRAWING 3 SIDED TRIANGLE
        glColor3f(0.f, 0.7f, 0.0f);
            glVertex2d(-25.0,0.0);
            glVertex2d(25.0,0.0);
            glVertex2d(0.0,25.0);
    glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(-135,-130,0);
    glBegin(GL_TRIANGLES); // DRAWING 3 SIDED TRIANGLE
        glColor3f(0.f, 0.7f, 0.0f);
            glVertex2d(-25.0,0.0);
            glVertex2d(25.0,0.0);
            glVertex2d(0.0,25.0);
    glEnd();
    glPopMatrix();

     glPushMatrix();
    glTranslatef(-135,-140,0);
    glBegin(GL_TRIANGLES); // DRAWING 3 SIDED TRIANGLE
        glColor3f(0.f, 0.7f, 0.0f);
            glVertex2d(-25.0,0.0);
            glVertex2d(25.0,0.0);
            glVertex2d(0.0,25.0);
    glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(-75,-90,0);
    glBegin(GL_TRIANGLES); // DRAWING 3 SIDED TRIANGLE
        glColor3f(0.f, 0.7f, 0.0f);
            glVertex2d(-25.0,0.0);
            glVertex2d(25.0,0.0);
            glVertex2d(0.0,25.0);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-75,-100,0);
    glBegin(GL_TRIANGLES); // DRAWING 3 SIDED TRIANGLE
        glColor3f(0.f, 0.8f, 0.0f);
            glVertex2d(-25.0,0.0);
            glVertex2d(25.0,0.0);
            glVertex2d(0.0,25.0);
    glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(-75,-110,0);
    glBegin(GL_TRIANGLES); // DRAWING 3 SIDED TRIANGLE
        glColor3f(0.f, 0.8f, 0.0f);
            glVertex2d(-25.0,0.0);
            glVertex2d(25.0,0.0);
            glVertex2d(0.0,25.0);
    glEnd();
    glPopMatrix();


     glPushMatrix();
    glTranslatef(15,-110,0);
    glBegin(GL_TRIANGLES); // DRAWING 3 SIDED TRIANGLE
        glColor3f(0.f, 0.8f, 0.0f);
            glVertex2d(-25.0,0.0);
            glVertex2d(25.0,0.0);
            glVertex2d(0.0,25.0);
    glEnd();
    glPopMatrix();

     glPushMatrix();
    glTranslatef(15,-120,0);
    glBegin(GL_TRIANGLES); // DRAWING 3 SIDED TRIANGLE
        glColor3f(0.f, 0.8f, 0.0f);
            glVertex2d(-25.0,0.0);
            glVertex2d(25.0,0.0);
            glVertex2d(0.0,25.0);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(15,-130,0);
    glBegin(GL_TRIANGLES);
        glColor3f(0.f, 0.8f, 0.0f);
            glVertex2d(-25.0,0.0);
            glVertex2d(25.0,0.0);
            glVertex2d(0.0,25.0);
    glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(75,-120,0);
    glBegin(GL_TRIANGLES);
        glColor3f(0.f, 0.8f, 0.0f);
            glVertex2d(-25.0,0.0);
            glVertex2d(25.0,0.0);
            glVertex2d(0.0,25.0);
    glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(75,-130,0);
    glBegin(GL_TRIANGLES);
        glColor3f(0.f, 0.8f, 0.0f);
            glVertex2d(-25.0,0.0);
            glVertex2d(25.0,0.0);
            glVertex2d(0.0,25.0);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(75,-140,0);
    glBegin(GL_TRIANGLES);
        glColor3f(0.f, 0.8f, 0.0f);
            glVertex2d(-25.0,0.0);
            glVertex2d(25.0,0.0);
            glVertex2d(0.0,25.0);
    glEnd();
    glPopMatrix();



    glPushMatrix();
    glTranslatef(125,-120,0);
    glBegin(GL_TRIANGLES);
        glColor3f(0.f, 0.8f, 0.0f);
            glVertex2d(-25.0,0.0);
            glVertex2d(25.0,0.0);
            glVertex2d(0.0,25.0);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(125,-130,0);
    glBegin(GL_TRIANGLES);
        glColor3f(0.f, 0.8f, 0.0f);
            glVertex2d(-25.0,0.0);
            glVertex2d(25.0,0.0);
            glVertex2d(0.0,25.0);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(125,-140,0);
    glBegin(GL_TRIANGLES);
        glColor3f(0.f, 0.8f, 0.0f);
            glVertex2d(-25.0,0.0);
            glVertex2d(25.0,0.0);
            glVertex2d(0.0,25.0);
    glEnd();
    glPopMatrix();

}
void triangle_Loop()
{           //2st tree
   glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.8f, 0.0f);
         glVertex2d(118,-63);
         glVertex2d(120,-63);
         glVertex2d(116,-53);
         glVertex2d(120,-53);
         glVertex2d(110,-40);

    glEnd();
    glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.8f, 0.0f);
         glVertex2d(120,-63);
         glVertex2d(125,-63);
         glVertex2d(120,-53);
         glVertex2d(125,-53);
         glVertex2d(123,-40);

    glEnd();
    glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.8f, 0.0f);
         glVertex2d(125,-63);
         glVertex2d(126,-63);
         glVertex2d(125,-53);
         glVertex2d(128,-53);
         glVertex2d(135,-45);

    glEnd();

    //5th
      glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.9f, 0.0f);
         glVertex2d(155,-60);
         glVertex2d(160,-60);
         glVertex2d(150,-50);
         glVertex2d(160,-50);
         glVertex2d(140,-36);

    glEnd();
      glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.9f, 0.0f);
         glVertex2d(150,-50);
         glVertex2d(160,-50);
         glVertex2d(150,-45);
         glVertex2d(160,-45);
         glVertex2d(155,-34);

    glEnd();
    glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.9f, 0.0f);
         glVertex2d(150,-60);
         glVertex2d(160,-60);
         glVertex2d(150,-50);
         glVertex2d(160,-50);
         glVertex2d(170,-40);

    glEnd();


    //4th tree
   glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.9f, 0.0f);
         glVertex2d(82,-67);
         glVertex2d(85,-67);
         glVertex2d(80,-50);
         glVertex2d(85,-50);
         glVertex2d(70,-35);

    glEnd();
      glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.9f, 0.0f);
         glVertex2d(85,-67);
         glVertex2d(90,-67);
         glVertex2d(85,-50);
         glVertex2d(90,-50);
         glVertex2d(87,-35);

    glEnd();
    glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.9f, 0.0f);
         glVertex2d(90,-67);
         glVertex2d(95,-67);
         glVertex2d(90,-50);
         glVertex2d(97,-50);
         glVertex2d(110,-40);

    glEnd();



       //3rd tree
   glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.8f, 0.0f);
         glVertex2d(55,-70);
         glVertex2d(58,-70);
         glVertex2d(55,-60);
         glVertex2d(58,-60);
         glVertex2d(45,-50);

    glEnd();
    glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.8f, 0.0f);
         glVertex2d(55,-70);
         glVertex2d(60,-70);
         glVertex2d(55,-60);
         glVertex2d(60,-60);
         glVertex2d(57,-45);

    glEnd();
     glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.8f, 0.0f);
         glVertex2d(58,-70);
         glVertex2d(60,-70);
         glVertex2d(58,-60);
         glVertex2d(60,-60);
         glVertex2d(68,-50);

    glEnd();


      //2st tree
   glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.8f, 0.0f);
         glVertex2d(28,-70);
         glVertex2d(30,-70);
         glVertex2d(28,-60);
         glVertex2d(30,-60);
         glVertex2d(20,-50);

    glEnd();
    glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.8f, 0.0f);
         glVertex2d(30,-70);
         glVertex2d(35,-70);
         glVertex2d(30,-60);
         glVertex2d(35,-60);
         glVertex2d(40,-50);

    glEnd();
    glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.8f, 0.0f);
         glVertex2d(30,-70);
         glVertex2d(35,-70);
         glVertex2d(30,-60);
         glVertex2d(35,-60);
         glVertex2d(31,-45);

    glEnd();

   //1st tree
    glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.9f, 0.0f);
         glVertex2d(-5,-75);
         glVertex2d(0,-75);
         glVertex2d(-8,-65);
         glVertex2d(0,-65);
         glVertex2d(-15,-50);
    glEnd();

    glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.9f, 0.0f);
         glVertex2d(-5,-75);
         glVertex2d(5,-75);
         glVertex2d(-5,-65);
         glVertex2d(5,-65);
         glVertex2d(0,-50);
    glEnd();
    //river side small tree
    glBegin(GL_TRIANGLE_STRIP);
        glColor3f(0.0f, 0.9f, 0.0f);
         glVertex2d(0,-75);
         glVertex2d(5,-75);
         glVertex2d(0,-65);
         glVertex2d(8,-65);
         glVertex2d(20,-50);

    glEnd();

}
void drawCircle(float radius_x, float radius_y)
{
	int i = 0;
	float angle = 0.0;
    //glColor3f(0,0.5,0);
	glBegin(GL_POLYGON);
    {
		for(i = 0; i < 100; i++)
		{
			angle = 2 * 3.1416 * i / 100;
			glVertex3f (cos(angle) * radius_x, sin(angle) * radius_y, 0);
		}

    }

	glEnd();
}

void s_quad()
{



        //road
      glBegin(GL_QUADS);
        glColor3f(0.5f, 0.5f, 0.5f);
        glVertex2d(75.0,0.0);
        glVertex2d(60.0,0.0);
        glVertex2d(65.0,25.0);
        glVertex2d(80.0,25.0);
       glEnd();

            //road
      glBegin(GL_QUADS);
        glColor3f(0.5f, 0.5f, 0.5f);
        glVertex2d(-170.0,-0.0);
        glVertex2d(0.0,-0.0);
        glVertex2d(0.0,-20.0);
        glVertex2d(-170.0,-20.0);
       glEnd();


         //road
       glBegin(GL_QUADS);
        glColor3f(0.5f, 0.5f, 0.5f);
        glVertex2d(170.0,-0.0);
        glVertex2d(0.0,-0.0);
        glVertex2d(0.0,-20.0);
        glVertex2d(170.0,-20.0);
       glEnd();

        //door
      glBegin(GL_QUADS);
        glColor3f(0.5f, 0.0f, 0.0f);
        glVertex2d(76.0,70.0);
        glVertex2d(74.0,70.0);
        glVertex2d(74.0,33.0);
        glVertex2d(76.0,33.0);
       glEnd();

         //door
     glBegin(GL_QUADS);
        glColor3f(0.75f, 0.75f, 0.75f);
        glVertex2d(87.0,70.0);
        glVertex2d(63.0,70.0);
        glVertex2d(63.0,33.0);
        glVertex2d(87.0,33.0);
        glEnd();


    //left window
       glBegin(GL_QUADS);
        glColor3f(0.5f, 0.0f, 0.0f);
        glVertex2d(44.0,65.0);
        glVertex2d(42.0,65.0);
        glVertex2d(42.0,45.0);
        glVertex2d(44.0,45.0);
        glEnd();

            //left window
       glBegin(GL_QUADS);
        glColor3f(0.5f, 0.0f, 0.0f);
        glVertex2d(36.0,65.0);
        glVertex2d(34.0,65.0);
        glVertex2d(34.0,45.0);
        glVertex2d(36.0,45.0);
       glEnd();;



        //left window
    glBegin(GL_QUADS);
        glColor3f(0.75f, 0.75f, 0.75f);
        glVertex2d(50.0,65.0);
        glVertex2d(30.0,65.0);
        glVertex2d(30.0,45.0);
        glVertex2d(50.0,45.0);
        glEnd();



    //right window
        glBegin(GL_QUADS);
        glColor3f(0.5f, 0.0f, 0.0f);
        glVertex2d(108.0,65.0);
        glVertex2d(106.0,65.0);
        glVertex2d(106.0,45.0);
        glVertex2d(108.0,45.0);
        glEnd();

           //right window
       glBegin(GL_QUADS);
        glColor3f(0.5f, 0.0f, 0.0f);
        glVertex2d(116.0,65.0);
        glVertex2d(114.0,65.0);
        glVertex2d(114.0,45.0);
        glVertex2d(116.0,45.0);
       glEnd();

        //right window
     glBegin(GL_QUADS);
        glColor3f(0.75f, 0.75f, 0.75f);
        glVertex2d(120.0,65.0);
        glVertex2d(100.0,65.0);
        glVertex2d(100.0,45.0);
        glVertex2d(120.0,45.0);
        glEnd();


    // river down side tree
     glBegin(GL_QUADS);
        glColor3f(0.5f, 0.0f, 0.0f);
        glVertex2d(-140.0,-170.0);
        glVertex2d(-130.0,-170.0);
        glVertex2d(-130.0,-130.0);
        glVertex2d(-140.0,-130.0);
        glEnd();



        //river down side tree
      glBegin(GL_QUADS);
        glColor3f(0.5f, 0.0f, 0.0f);
        glVertex2d(-80.0,-140.0);
        glVertex2d(-70.0,-140.0);
        glVertex2d(-70.0,-100.0);
        glVertex2d(-80.0,-100.0);
      glEnd();

         //river down side tree
      glBegin(GL_QUADS);
        glColor3f(0.5f, 0.0f, 0.0f);
        glVertex2d(10.0,-150.0);
        glVertex2d(20.0,-150.0);
        glVertex2d(20.0,-110.0);
        glVertex2d(10.0,-110.0);
      glEnd();

      //river down side tree
      glBegin(GL_QUADS);
        glColor3f(0.5f, 0.0f, 0.0f);
        glVertex2d( 70.0,-160.0);
        glVertex2d(80.0,-160.0);
        glVertex2d(80.0,-120.0);
        glVertex2d(70.0,-120.0);
      glEnd();



        //river down side tree
      glBegin(GL_QUADS);
        glColor3f(0.5f, 0.0f, 0.0f);
        glVertex2d( 120.0,-160.0);
        glVertex2d(130.0,-160.0);
        glVertex2d(130.0,-120.0);
        glVertex2d(120.0,-120.0);
      glEnd();


     //cloud 3
    glPushMatrix();
        glColor3f(0.9f, 0.9f, 0.9f);
       glTranslatef(80,150,0);
        drawCircle(8,8);
    glPopMatrix();

      //cloud 3
     glPushMatrix();
        glColor3f(0.9f, 0.9f, 0.9f);
       glTranslatef(80,140,0);
        drawCircle(12,12);
    glPopMatrix();

      //cloud 3
    glPushMatrix();
        glColor3f(0.9f, 0.9f, 0.9f);
       glTranslatef(95,140,0);
        drawCircle(12,12);
    glPopMatrix();

    //cloud 3
    glPushMatrix();
        glColor3f(0.9f, 0.9f, 0.9f);
        glTranslatef(65,140,0);
        drawCircle(12,12);
    glPopMatrix();


     //cloud 2
 glPushMatrix();
        glColor3f(0.9f, 0.9f, 0.9f);
        glTranslatef(-30,110,0);
        drawCircle(8,8);
    glPopMatrix();

      //cloud 2
    glPushMatrix();
        glColor3f(0.9f, 0.9f, 0.9f);
       glTranslatef(-30,120,0);
        drawCircle(12,12);
    glPopMatrix();

     //cloud 2
    glPushMatrix();
    glColor3f(0.9f, 0.9f, 0.9f);
       glTranslatef(-20,120,0);
        drawCircle(12,12);
    glPopMatrix();

     //cloud 2
    glPushMatrix();
        glColor3f(0.9f, 0.9f, 0.9f);
        glTranslatef(-45,120,0);
        drawCircle(12,12);
    glPopMatrix();

    //cloud 1
   glPushMatrix();
       glColor3f(1.0f, 1.0f, 1.93f);
       glTranslatef(-75,140,0);
        drawCircle(12,12);
    glPopMatrix();

     //cloud 1
    glPushMatrix();
        glColor3f(1.0f, 1.0f, 1.93f);
       glTranslatef(-85,140,0);
        drawCircle(12,12);
    glPopMatrix();

    //cloud1
    glPushMatrix();
        glColor3f(1.0f, 1.0f, 1.93f);
       glTranslatef(-100,140,0);
        drawCircle(12,12);
    glPopMatrix();

    //sun
    glPushMatrix();
        glColor3f(1.0f, 0.88f, 0.20f);
       glTranslatef(-150,150,0);
        drawCircle(10,10);
    glPopMatrix();

      //2nd tree leaf
    glPushMatrix();
       glTranslatef(-55,100,0);
       glColor3f(0,0.5,0);
        drawCircle(10,10);
    glPopMatrix();

      //2nd tree leaf
    glPushMatrix();
       glTranslatef(-45,90,0);
       glColor3f(0,0.5,0);
        drawCircle(10,10);
    glPopMatrix();


      //2nd tree leaf
    glPushMatrix();
       glTranslatef(-65,90,0);
       glColor3f(0,0.5,0);
        drawCircle(10,10);
    glPopMatrix();

     //2nd tree leaf
    glPushMatrix();
       glTranslatef(-55,90,0);
       glColor3f(0,0.5,0);
        drawCircle(10,10);
    glPopMatrix();

       //2nd tree root
     glPushMatrix();
        glTranslatef(-55,50,0);
        glBegin(GL_TRIANGLES);
        glColor3f(0.5f, 0.0f, 0.0f);
         glVertex2d(0.0,2.0);
         glVertex2d(0.0,-2.0);
         glVertex2d(8.0,0.0);
    glEnd();
    glPopMatrix();


     //2nd tree root
    glPushMatrix();
        glTranslatef(-55,50,0);
        glBegin(GL_TRIANGLES);
         glColor3f(0.5f, 0.0f, 0.0f);
         glVertex2d(0.0,2.0);
         glVertex2d(0.0,-2.0);
         glVertex2d(-8.0,0.0);
    glEnd();
    glPopMatrix();

      //2nd tree root
    glPushMatrix();
        glTranslatef(-55,50,0);
        glBegin(GL_TRIANGLES);
         glColor3f(0.5f, 0.0f, 0.0f);
         glVertex2d(-4.0,0.0);
         glVertex2d(4.0,0.0);
         glVertex2d(0.0,-8.0);
    glEnd();
    glPopMatrix();

    //2nd tree
    glBegin(GL_QUADS);
        glColor3f(0.5f, 0.0f, 0.0f);
        glVertex2d( -60.0,50.0);
        glVertex2d(-50.0,50.0);
        glVertex2d(-50.0,90.0);
        glVertex2d(-60.0,90.0);
    glEnd();

    //left most tree leaf
    glPushMatrix();
       glTranslatef(-135,80,0);
       glColor3f(0,0.5,0);
        drawCircle(10,10);
    glPopMatrix();

   //left most tree leaf
    glPushMatrix();
       glTranslatef(-145,70,0);
       glColor3f(0,0.5,0);
        drawCircle(10,10);
    glPopMatrix();

       //left most tree leaf
    glPushMatrix();
       glTranslatef(-125,70,0);
       glColor3f(0,0.5,0);
        drawCircle(10,10);
    glPopMatrix();

      //left most tree leaf
    glPushMatrix();
       glTranslatef(-135,70,0);
       glColor3f(0,0.5,0);
        drawCircle(10,10);
    glPopMatrix();

         //left most tree root
     glPushMatrix();
        glTranslatef(-135,30,0);
        glBegin(GL_TRIANGLES);
        glColor3f(0.5f, 0.0f, 0.0f); glVertex2d(0.0,2.0);
        glColor3f(0.5f, 0.0f, 0.0f); glVertex2d(0.0,-2.0);
        glColor3f(0.5f, 0.0f, 0.0f); glVertex2d(8.0,0.0);
    glEnd();
    glPopMatrix();


        //left most tree root
    glPushMatrix();
        glTranslatef(-135,30,0);
        glBegin(GL_TRIANGLES);
        glColor3f(0.5f, 0.0f, 0.0f);
         glVertex2d(0.0,2.0);
         glVertex2d(0.0,-2.0);
         glVertex2d(-8.0,0.0);
    glEnd();
    glPopMatrix();

        //left most tree root
    glPushMatrix();
        glTranslatef(-135,30,0);
        glBegin(GL_TRIANGLES);
        glColor3f(0.5f, 0.0f, 0.0f);
         glVertex2d(-4.0,0.0);
         glVertex2d(4.0,0.0);
         glVertex2d(0.0,-8.0);
    glEnd();

    //left-most tree
    glPopMatrix();
      glBegin(GL_QUADS);
        glColor3f(0.5f, 0.0f, 0.0f);
        glVertex2d( -140.0,30.0);
        glVertex2d(-130.0,30.0);
        glVertex2d(-130.0,70.0);
        glVertex2d(-140.0,70.0);
    glEnd();

        //school roof
     glBegin(GL_QUADS);
        glColor3f(0.7f, 0.0f, 0.0f);
        glVertex2d( 10.0,80.0);
        glVertex2d(140.0,80.0);
        glVertex2d(135.0,100.0);
        glVertex2d(15.0,100.0);
     glEnd();

       //school wall
    glBegin(GL_QUADS);
        glColor3f(0.7f, 0.5f, 0.0f);
        glVertex2d( 20.0,30.0);
        glVertex2d(130.0,30.0);
        glVertex2d(130.0,85.0);
        glVertex2d(20.0,85.0);
    glEnd();

       //sky
    glBegin(GL_QUADS);
        glColor3f(0.5f, 0.8f, 0.9f);
        glVertex2d( -200.0,90.0);
        glVertex2d(200.0,90.0);
        glVertex2d(200.0,200.0);
        glVertex2d(-200.0,200.0);
    glEnd();

         //top most field
      glBegin(GL_QUADS);
        glColor3f(0.5f, 0.8f, 0.0f);
        glVertex2d( -200.0,50.0);
        glVertex2d(200.0,50.0);
        glVertex2d(200.0,90.0);
        glVertex2d(-200.0,90.0);
      glEnd();

      //river up side field
    glBegin(GL_QUADS);
        glColor3f(0.0f, 0.4f, 0.0f);
        glVertex2d(-200.0,-88.0);
        glVertex2d(200.0,-58.0);
        glVertex2d(200.0,50.0);
        glVertex2d(-200.0,50.0);
    glEnd();

      //river
    glPushMatrix();
    glTranslatef(0,incy,0); //river move
    glBegin(GL_QUADS);
        glColor3f(0.0f, 0.4f, 0.7f);
        glVertex2d(-200.0,-120.0);
        glVertex2d(200.0,-90.0);
        glVertex2d(200.0,-50.0);
        glVertex2d(-200.0,-80.0);
    glEnd();
    glPopMatrix();

       //river down side field
    glBegin(GL_QUADS);
        glColor3f(0.0f, 0.5f, 0.0f);
        glVertex2d(-200.0,-200.0);
        glVertex2d(200.0,-200.0);
        glVertex2d(200.0,-92.0);
        glVertex2d(-200.0,-122.0);
    glEnd();



}

void s_poly()
{
    glBegin(GL_POLYGON); // DRAWING POLYGON
        glColor3f(1.0, 1.0, 0.0); // yellow
        glVertex2f(0.0, 0.0) ;
        glVertex2f(0.0, 3.0) ;
        glVertex2f(4.0, 3.0) ;
        glVertex2f(4.5, 1.5) ;
        glVertex2f(4.0, 0.0);
    glEnd();

}








void drawSquare(double a)
{
    //glColor3f(1.0,0.0,0.0);
	glBegin(GL_QUADS);{
		glVertex3f( a, a,2);
		glVertex3f( a,-a,2);
		glVertex3f(-a,-a,2);
		glVertex3f(-a, a,2);
	}glEnd();
}

void pCurve()
{

}

void rec_animation()
{
    //glColor3f(.6,1,.8);
    //glRotatef(angle,0,0,1);
    //glTranslatef(incx,incy,0);
    //glRotatef(10*angle,0,0,1);
    //drawCircle(1,1);
    glBegin(GL_QUADS); // DRAWING 4 SIDED QUADRILATERAL
        glColor3f(1.f, 0.0f, 0.0f);
        glVertex2d(70.0,65.0);
        glVertex2d(30.0,65.0);//school
        glVertex2d(30.0,45.0);
        glVertex2d(70.0,45.0);
        glEnd();


}
void draw_rec()
{
    //glColor3f(0,1,0);

    drawSquare(5);

}
void trans()
{
    glRotatef(40,0,0,1);

    glTranslatef(30,0,0);
    glScaled(7,1,1);
    drawSquare(2);
}
void simple_trans()
{
    glPushMatrix();
    glRotatef(40, 0, 0, 1);
    glTranslatef(-20, 0, 0);
    glColor3f(0.0, 1.0, 0.0);
    draw_rec();
    glPopMatrix();

    glTranslatef(20, 0, 0);
    glColor3f(0.0, 0.0, 1.0);
    draw_rec();
}
double curve_by_points()
{
    ///
}
double func(double x)
{
    return x*sin(x);
}
void curve()
{
    glColor3f(0.0f, 1.0f, 0.0f);
    glBegin(GL_LINES);
    for(double i =-180; i<180;i+=.1)
    {
        glVertex2d(i,func(i));
        glVertex2d(i+.1, func(i+.1));
    }
     // It can be any type Gl_POINT,_LINE
    glEnd();

}
void display(){

	//clear the display
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(0,0,0,0);	//color black
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


	//load the correct matrix -- MODEL-VIEW matrix
	glMatrixMode(GL_MODELVIEW);

	//initialize the matrix
	glLoadIdentity();

	//now give three info
	//1. where is the camera (viewer)?
	//2. where is the camera looking?
	//3. Which direction is the camera's UP direction?

	//gluLookAt(100,100,100,	0,0,0,	0,0,1);
	//gluLookAt(200*cos(cameraAngle), 200*sin(cameraAngle), cameraHeight,		0,0,0,		0,0,1);
	gluLookAt(0,0,200,	0,0,0,	0,1,0);


	//again select MODEL-VIEW
	glMatrixMode(GL_MODELVIEW);




	just_line();//bird
	//line();
	//triangle();
	s_triangle();//river down side tree leaf
    triangle_Loop();//river side tree
	s_quad();









	//ADD this line in the end --- if you use double buffer (i.e. GL_DOUBLE)
	glutSwapBuffers();
}


void animate(){
    //rotation
    angle-=0.05;

	//codes for any changes in Models, Camera
	//linear_oscillation

    if(state ==0 && incy>-5){ state =1;}
    if(state ==1 && incy <-10){state =0;}

    if(state == 0) incy+=0.0005;
    else incy-=0.0005;

    //incy = func(incx);


	glutPostRedisplay();
}

void init(){
	//codes for initialization
	drawgrid=0;
	drawaxes=1;
	cameraHeight=150.0;
	cameraAngle=1.0;
	angle=0;

	//clear the screen
	glClearColor(0,0,0,0);


	//load the PROJECTION matrix
	glMatrixMode(GL_PROJECTION);

	//initialize the matrix
	glLoadIdentity();

	//give PERSPECTIVE parameters
	gluPerspective(80,	1,	1,	1000.0);
	//field of view in the Y (vertically)
	//aspect ratio that determines the field of view in the X direction (horizontally)
	//near distance
	//far distance
}

int main(int argc, char **argv){
	glutInit(&argc,argv);
	glutInitWindowSize(800, 800);
	glutInitWindowPosition(0, 0);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB);	//Depth, Double buffer, RGB color

	glutCreateWindow("My OpenGL Program");

	init();

	glEnable(GL_DEPTH_TEST);	//enable Depth Testing

	glutDisplayFunc(display);	//display callback function
	glutIdleFunc(animate);		//what you want to do in the idle time (when no drawing is occuring)

	//glutKeyboardFunc(keyboardListener);
	//glutSpecialFunc(specialKeyListener);
	//glutMouseFunc(mouseListener);

	glutMainLoop();		//The main loop of OpenGL

	return 0;
}
